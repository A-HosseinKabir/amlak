import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Property, PropertyType } from '../types/property';
import { 
  X, Bed, Bath, Square, MapPin, Play, View as View360, Share2, Heart, 
  MessageCircle, ChevronLeft, ChevronRight, Calendar, Layers, LayoutGrid,
  ParkingCircle, Box, ArrowUpCircle, Flame, Waves, ShieldCheck, Phone,
  Clock, CheckCircle, CalendarRange, Info, Trash2, ShieldAlert
} from 'lucide-react';
import PropertyMap from './PropertyMap';

interface PropertyDetailProps {
  property: Property;
  onClose: () => void;
  onChatClick: () => void;
  isDark?: boolean;
  isBookmarked?: boolean;
  onToggleBookmark?: () => void;
}

const FEATURE_ICONS: Record<string, React.ReactNode> = {
  'پارکینگ': <ParkingCircle className="w-5 h-5" />,
  'انباری': <Box className="w-5 h-5" />,
  'آسانسور': <ArrowUpCircle className="w-5 h-5" />,
  'گرمایش مرکزی': <Flame className="w-5 h-5" />,
  'استخر': <Waves className="w-5 h-5" />,
  'لابی من': <ShieldCheck className="w-5 h-5" />,
  'روف گاردن': <LayoutGrid className="w-5 h-5" />,
};

const DAYS = [
  { key: 'today', name: 'یکشنبه (امروز)', date: '۴ خرداد' },
  { key: 'day2', name: 'دوشنبه (فردا)', date: '۵ خرداد' },
  { key: 'day3', name: 'سه‌شنبه', date: '۶ خرداد' },
  { key: 'day4', name: 'چهارشنبه', date: '۷ خرداد' },
  { key: 'day5', name: 'پنجشنبه', date: '۸ خرداد' },
  { key: 'day6', name: 'جمعه', date: '۹ خرداد' },
  { key: 'day7', name: 'شنبه', date: '۱۰ خرداد' },
];

const TIME_SLOTS = [
  '۱۰:۰۰ - ۱۲:۰۰ (صبح)',
  '۱۲:۰۰ - ۱۴:۰۰ (ظهر)',
  '۱۴:۰۰ - ۱۶:۰۰ (عصر)',
  '۱۶:۰۰ - ۱۸:۰۰ (عصر)',
  '۱۸:۰۰ - ۲۰:۰۰ (غروب)',
];

export default function PropertyDetail({ 
  property, 
  onClose, 
  onChatClick, 
  isDark = false,
  isBookmarked = false,
  onToggleBookmark
}: PropertyDetailProps) {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [isTourOpen, setIsTourOpen] = useState(false);
  const [isGalleryOpen, setIsGalleryOpen] = useState(false);

  // Appointment states
  const [selectedDayIndex, setSelectedDayIndex] = useState(0);
  const [selectedSlotIndex, setSelectedSlotIndex] = useState(0);
  const [bookingType, setBookingType] = useState<'in_person' | 'video_call'>('in_person');
  const [bookingNote, setBookingNote] = useState('');
  const [isBookingSubmitted, setIsBookingSubmitted] = useState(false);

  const [inspectionRequests, setInspectionRequests] = useState<any[]>(() => {
    try {
      const saved = localStorage.getItem('inspectionRequests');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const nextImage = () => {
    setCurrentImageIndex((prev) => (prev + 1) % property.images.length);
  };

  const prevImage = () => {
    setCurrentImageIndex((prev) => (prev - 1 + property.images.length) % property.images.length);
  };

  const handleBookingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newRequest = {
      id: `req-${Date.now()}`,
      propertyId: property.id,
      propertyTitle: property.title,
      propertyAddress: property.location.address,
      propertyImage: property.images[0],
      day: DAYS[selectedDayIndex].name,
      date: DAYS[selectedDayIndex].date,
      timeSlot: TIME_SLOTS[selectedSlotIndex],
      type: bookingType === 'in_person' ? 'حضوری' : 'مشاوره تصویری',
      note: bookingNote,
      createdAt: Date.now(),
      status: 'pending_owner_approval' // 'در انتظار تایید مالک'
    };

    const updated = [newRequest, ...inspectionRequests];
    setInspectionRequests(updated);
    localStorage.setItem('inspectionRequests', JSON.stringify(updated));
    setIsBookingSubmitted(true);
  };

  return (
    <motion.div
      initial={{ y: '100%' }}
      animate={{ y: 0 }}
      exit={{ y: '100%' }}
      transition={{ type: 'spring', damping: 25, stiffness: 200 }}
      className="fixed inset-0 md:left-0 md:right-64 z-[60] bg-slate-50 dark:bg-slate-950 overflow-y-auto scrollbar-hide flex flex-col"
      dir="rtl"
    >
      {/* HEADER SECTION */}
      <div className="bg-white dark:bg-slate-900 border-b border-slate-200/60 dark:border-slate-800/80 px-4 md:px-8 py-4 sticky top-0 z-40 flex items-center justify-between shadow-sm transition-colors">
        <div className="flex items-center gap-4">
          <button
            onClick={onClose}
            className="w-11 h-11 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700/80 rounded-2xl flex items-center justify-center text-slate-700 dark:text-slate-300 transition-all cursor-pointer active:scale-95 border border-slate-200/30 dark:border-slate-700"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
          <div>
            <span className="text-blue-600 dark:text-blue-400 font-black text-xs px-2.5 py-1 bg-blue-50 dark:bg-blue-900/20 rounded-lg ml-2">
              {property.type}
            </span>
            <span className="text-[11px] text-slate-400 dark:text-slate-500 font-bold">منتشر شده در روزهای اخیر</span>
            <h1 className="text-base md:text-lg font-black text-slate-900 dark:text-white mt-1 leading-none line-clamp-1 max-w-[250px] md:max-w-md">
              {property.title}
            </h1>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button 
            onClick={onToggleBookmark}
            className={`w-11 h-11 rounded-2xl flex items-center justify-center transition-all cursor-pointer active:scale-95 border ${
              isBookmarked 
                ? 'bg-rose-50 border-rose-100 text-rose-500 dark:bg-rose-900/25 dark:border-rose-900' 
                : 'bg-slate-50 hover:bg-slate-100 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-500 dark:text-slate-400 border-slate-200/30 dark:border-slate-700'
            }`}
          >
            <Heart className={`w-5 h-5 ${isBookmarked ? 'fill-current' : ''}`} />
          </button>
          <button className="w-11 h-11 bg-slate-50 hover:bg-slate-100 dark:bg-slate-800 dark:hover:bg-slate-700 rounded-2xl flex items-center justify-center text-slate-500 dark:text-slate-400 transition-all cursor-pointer active:scale-95 border border-slate-200/30 dark:border-slate-700">
            <Share2 className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* LUXURY PHOTO GALLERY SECTION FOR DESKTOP & MOBILE */}
      <div className="w-full max-w-7xl mx-auto px-4 md:px-8 pt-6">
        {/* Desktop grid layout */}
        <div className="hidden md:grid grid-cols-3 gap-4 h-[380px] rounded-[2rem] overflow-hidden shadow-md">
          {/* Main big image */}
          <div className="col-span-2 relative group overflow-hidden cursor-pointer" onClick={() => setIsGalleryOpen(true)}>
            <img 
              src={property.images[0]} 
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" 
              alt={property.title}
            />
            <div className="absolute inset-0 bg-black/10 group-hover:bg-black/20 transition-colors" />
            
            {/* virtual tour short tag */}
            {property.virtualTourUrl && (
              <div className="absolute bottom-6 right-6 bg-blue-600/90 text-white px-4 py-2.5 rounded-2xl flex items-center gap-2 text-xs font-black shadow-lg">
                <View360 className="w-4 h-4" />
                دارای تور مجازی ۳۶۰ درجه
              </div>
            )}
          </div>

          {/* Secondary stacked images */}
          <div className="col-span-1 grid grid-rows-2 gap-4 h-full">
            <div className="relative group overflow-hidden cursor-pointer rounded-r-none" onClick={() => setIsGalleryOpen(true)}>
              <img 
                src={property.images[1] || property.images[0]} 
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" 
                alt="نمای داخلی ملک"
              />
              <div className="absolute inset-0 bg-black/10 group-hover:bg-black/20 transition-colors" />
            </div>
            <div className="relative group overflow-hidden cursor-pointer" onClick={() => setIsGalleryOpen(true)}>
              <img 
                src={property.images[2] || property.images[0]} 
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" 
                alt="پذیرایی یا آشپزخانه ملک"
              />
              <div className="absolute inset-0 bg-black/20 group-hover:bg-black/30 transition-colors" />
              <div className="absolute inset-0 flex items-center justify-center text-white font-black text-sm drop-shadow backdrop-blur-xs">
                <span className="bg-slate-950/70 py-2 px-5 rounded-full ring-1 ring-white/10">مشاهده گالری تصاویر ({property.images.length.toLocaleString('fa-IR')})</span>
              </div>
            </div>
          </div>
        </div>

        {/* Mobile slide layout */}
        <div className="md:hidden relative h-[250px] bg-slate-950 rounded-[2rem] overflow-hidden shadow-md">
          <AnimatePresence mode="wait">
            <motion.img
              key={currentImageIndex}
              src={property.images[currentImageIndex]}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              alt={`${property.title} - ${currentImageIndex + 1}`}
              className="w-full h-full object-cover"
              onClick={() => setIsGalleryOpen(true)}
            />
          </AnimatePresence>

          {/* Counter Overlay */}
          <div className="absolute bottom-4 left-4 bg-black/50 backdrop-blur-md text-white px-3 py-1 rounded-full text-[10px] font-black leading-none border border-white/10">
            {(currentImageIndex + 1).toLocaleString('fa-IR')} از {property.images.length.toLocaleString('fa-IR')}
          </div>

          {/* Slider Prev/Next Navigation */}
          {property.images.length > 1 && (
            <>
              <button
                onClick={prevImage}
                className="absolute right-3 top-1/2 -translate-y-1/2 w-9 h-9 bg-black/35 backdrop-blur-md rounded-full flex items-center justify-center text-white active:scale-90 transition-all"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
              <button
                onClick={nextImage}
                className="absolute left-3 top-1/2 -translate-y-1/2 w-9 h-9 bg-black/35 backdrop-blur-md rounded-full flex items-center justify-center text-white active:scale-90 transition-all"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
            </>
          )}

          {/* Tour/Video Overlays on mobile */}
          <div className="absolute bottom-4 right-4 flex gap-2">
            {property.virtualTourUrl && (
              <button 
                onClick={() => setIsTourOpen(true)}
                className="bg-blue-600/90 backdrop-blur-md text-white px-3 py-1.5 rounded-xl flex items-center gap-1.5 text-[10px] font-bold shadow-lg"
              >
                <View360 className="w-3 h-3 animate-ping" />
                تور مجازی ۳۶۰°
              </button>
            )}
          </div>
        </div>
      </div>

      {/* CONTENT DIVISION: 2-COLUMN LUXURY GRID */}
      <div className="w-full max-w-7xl mx-auto px-4 md:px-8 py-8 grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* RIGHT COLUMN: CORE TECHNICAL SPECIFICATIONS & DETAILS (2/3 width) */}
        <div className="lg:col-span-2 space-y-8">
          
          {/* Main Title, price rating, details tags */}
          <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] p-6 md:p-8 border border-slate-200/50 dark:border-slate-800/80 shadow-xs">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
              <div>
                <h2 className="text-xl md:text-2xl font-black text-slate-900 dark:text-white leading-snug">
                  {property.title}
                </h2>
                <div className="flex items-center gap-2 text-slate-500 dark:text-slate-400 mt-3 text-sm">
                  <MapPin className="w-4 h-4 text-blue-500 shrink-0" />
                  <span>{property.location.address}</span>
                </div>
              </div>
              <div className="bg-slate-50 dark:bg-slate-800/40 p-4 rounded-3xl border border-slate-100 dark:border-slate-800 shrink-0 text-right">
                <p className="text-[10px] text-slate-450 dark:text-slate-505 font-bold mb-1">قیمت نهایی کارشناسی</p>
                <p className="text-xl md:text-2xl font-black text-blue-600 dark:text-blue-400">
                  {(property.price / 1000000000).toLocaleString('fa-IR')} <span className="text-xs font-black text-slate-500 dark:text-slate-450">میلیارد تومان</span>
                </p>
              </div>
            </div>

            {/* Core Specs Grid */}
            <div className="grid grid-cols-3 gap-3 md:gap-4 border-t border-slate-100 dark:border-slate-800/60 pt-6">
              <div className="bg-slate-50 dark:bg-slate-800/40 p-4 rounded-3xl flex flex-col items-center justify-center text-center border border-slate-100 dark:border-slate-800">
                <div className="w-10 h-10 bg-blue-50 dark:bg-blue-900/10 rounded-2xl flex items-center justify-center text-blue-600 dark:text-blue-400 mb-2">
                  <Bed className="w-5 h-5" />
                </div>
                <span className="font-extrabold text-slate-900 dark:text-white text-base">
                  {property.bedrooms.toLocaleString('fa-IR')}
                </span>
                <span className="text-[10px] text-slate-400 font-bold mt-1">اتاق خواب</span>
              </div>

              <div className="bg-slate-50 dark:bg-slate-800/40 p-4 rounded-3xl flex flex-col items-center justify-center text-center border border-slate-100 dark:border-slate-800">
                <div className="w-10 h-10 bg-indigo-50 dark:bg-indigo-900/10 rounded-2xl flex items-center justify-center text-indigo-600 dark:text-indigo-400 mb-2">
                  <Bath className="w-5 h-5" />
                </div>
                <span className="font-extrabold text-slate-900 dark:text-white text-base">
                  {property.bathrooms.toLocaleString('fa-IR')}
                </span>
                <span className="text-[10px] text-slate-400 font-bold mt-1">سرویس بهداشتی</span>
              </div>

              <div className="bg-slate-50 dark:bg-slate-800/40 p-4 rounded-3xl flex flex-col items-center justify-center text-center border border-slate-100 dark:border-slate-800">
                <div className="w-10 h-10 bg-emerald-50 dark:bg-emerald-900/10 rounded-2xl flex items-center justify-center text-emerald-600 dark:text-emerald-400 mb-2">
                  <Square className="w-5 h-5" />
                </div>
                <span className="font-extrabold text-slate-900 dark:text-white text-base">
                  {property.area.toLocaleString('fa-IR')}
                </span>
                <span className="text-[10px] text-slate-400 font-bold mt-1">متراژ (مترمربع)</span>
              </div>
            </div>
          </div>

          {/* Secondary Specifications panel */}
          <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] p-6 md:p-8 border border-slate-200/50 dark:border-slate-800/80 shadow-xs">
            <h3 className="font-black text-base md:text-lg text-slate-900 dark:text-white mb-6">جزئیات و مشخصات فنی</h3>
            
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <SpecDetailItem label="سال ساخت" value={property.yearBuilt ? property.yearBuilt.toLocaleString('fa-IR') : '۱۴۰۱'} />
              <SpecDetailItem label="سند ملک" value={property.type === PropertyType.LAND ? 'منگوله‌دار' : 'تک برگ هولوگرام‌دار'} />
              <SpecDetailItem label="جهت بنا" value="شمالی - شرقی" />
              <SpecDetailItem label="نوع اسکلت" value="بتن آرمه ضد زلزله" />
              {property.type === PropertyType.APARTMENT && (
                <>
                  <SpecDetailItem label="تعداد کل طبقات" value={property.totalFloors ? property.totalFloors.toLocaleString('fa-IR') : '۶'} />
                  <SpecDetailItem label="تعداد واحد در طبقه" value={property.unitsPerFloor ? property.unitsPerFloor.toLocaleString('fa-IR') : '۲'} />
                  <SpecDetailItem label="وضعیت سکونت" value="تخلیه آماده تحویل" />
                  <SpecDetailItem label="نمای ساختمان" value="سنگ رومی مدرن" />
                </>
              )}
            </div>
          </div>

          {/* Description Section */}
          <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] p-6 md:p-8 border border-slate-200/50 dark:border-slate-800/80 shadow-xs">
            <h3 className="font-black text-base md:text-lg text-slate-900 dark:text-white mb-4">توضیحات تکمیلی آگهی</h3>
            <p className="text-slate-600 dark:text-slate-400 text-sm md:text-base leading-8 md:leading-9 text-justify font-medium">
              {property.description}
            </p>
          </div>

          {/* Features Column */}
          <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] p-6 md:p-8 border border-slate-200/50 dark:border-slate-800/80 shadow-xs">
            <h3 className="font-black text-base md:text-lg text-slate-900 dark:text-white mb-6">امکانات رفاهی و ایمنی</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {(property.features || ['پارکینگ', 'انباری', 'آسانسور', 'لابی من', 'روف گاردن', 'استخر']).map(feat => (
                <div key={feat} className="flex items-center gap-3 bg-slate-50 dark:bg-slate-800/30 p-4 rounded-2xl border border-slate-100 dark:border-slate-800 transition-colors">
                  <div className="w-9 h-9 bg-white dark:bg-slate-800 rounded-xl flex items-center justify-center text-blue-600 dark:text-blue-400 shadow-xs border border-slate-100 dark:border-slate-705 shrink-0">
                    {FEATURE_ICONS[feat] || <div className="w-2 h-2 bg-blue-600 rounded-full" />}
                  </div>
                  <span className="text-slate-700 dark:text-slate-300 text-xs md:text-sm font-bold">{feat}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Map Section */}
          <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] p-6 md:p-8 border border-slate-200/50 dark:border-slate-800/80 shadow-xs">
            <h3 className="font-black text-base md:text-lg text-slate-900 dark:text-white mb-6">موقعیت دقیق ملک روی نقشه نشان</h3>
            <div className="h-80 bg-slate-100 dark:bg-slate-950 rounded-3xl overflow-hidden border border-slate-200/60 dark:border-slate-800 group relative">
              <PropertyMap 
                properties={[property]} 
                onMarkerClick={() => {}} 
                center={property.location} 
                zoom={14}
                isDark={isDark}
              />
              <div className="absolute top-4 right-4 z-10 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md px-3 py-1.5 rounded-xl text-[9px] font-black text-slate-500 shadow-md border border-slate-100 dark:border-slate-800 tracking-wider">
                نقشه تعاملی نشان
              </div>
            </div>
          </div>
        </div>

        {/* LEFT COLUMN: STICKY BOOKING FORM & ACTIONS SIDEBAR PANEL (1/3 width) */}
        <div className="lg:col-span-1 space-y-6">
          
          {/* Appointment/inspection Request Form widget! */}
          <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] p-6 border-2 border-blue-500/20 dark:border-blue-500/30 shadow-xl overflow-hidden sticky top-24">
            
            <div className="flex items-center gap-3 pb-4 mb-5 border-b border-slate-100 dark:border-slate-800">
              <div className="w-10 h-10 bg-blue-50 dark:bg-blue-900/20 rounded-2xl flex items-center justify-center text-blue-600 dark:text-blue-400">
                <CalendarRange className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-black text-sm text-slate-905 dark:text-white">درخواست آنلاین بازدید ملک</h3>
                <p className="text-[10px] text-slate-400 dark:text-slate-500 font-bold mt-0.5">زمان دلخواه خود را رزرو کنید</p>
              </div>
            </div>

            <AnimatePresence mode="wait">
              {!isBookingSubmitted ? (
                <motion.form 
                  key="booking-form"
                  onSubmit={handleBookingSubmit}
                  className="space-y-5"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                >
                  {/* Select Day */}
                  <div>
                    <span className="text-xs text-slate-500 dark:text-slate-400 font-black block mb-2.5">۱. انتخاب روز بازدید:</span>
                    <div className="flex gap-2.5 overflow-x-auto pb-1 scrollbar-hide -mx-2 px-2">
                      {DAYS.map((day, idx) => (
                        <button
                          key={day.key}
                          type="button"
                          onClick={() => setSelectedDayIndex(idx)}
                          className={`px-3.5 py-2.5 rounded-2xl border text-xs font-black transition-all shrink-0 cursor-pointer flex flex-col items-center gap-1 ${
                            selectedDayIndex === idx
                              ? 'bg-blue-600 text-white border-blue-600 shadow-md shadow-blue-500/10'
                              : 'bg-slate-50 dark:bg-slate-800 border-slate-200/50 dark:border-slate-800 text-slate-700 dark:text-slate-300'
                          }`}
                        >
                          <span className="text-[10px] leading-tight">{day.name}</span>
                          <span className={`text-[11px] opacity-80 ${selectedDayIndex === idx ? 'text-white' : 'text-blue-500'}`}>{day.date}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Select Time Slot */}
                  <div>
                    <span className="text-xs text-slate-500 dark:text-slate-400 font-black block mb-2.5">۲. انتخاب بازه زمانی:</span>
                    <div className="grid grid-cols-1 gap-2">
                      {TIME_SLOTS.map((slot, idx) => (
                        <button
                          key={slot}
                          type="button"
                          onClick={() => setSelectedSlotIndex(idx)}
                          className={`w-full py-2.5 px-4 rounded-xl border text-right text-xs font-bold transition-all cursor-pointer flex items-center justify-between ${
                            selectedSlotIndex === idx
                              ? 'bg-blue-50 border-blue-400 text-blue-700 dark:bg-blue-900/20 dark:border-blue-500 dark:text-blue-405'
                              : 'bg-slate-50 dark:bg-slate-800/50 border-slate-200/50 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-100'
                          }`}
                        >
                          <span>{slot}</span>
                          <Clock className={`w-4 h-4 ${selectedSlotIndex === idx ? 'text-blue-600' : 'text-slate-300'}`} />
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Booking type */}
                  <div>
                    <span className="text-xs text-slate-500 dark:text-slate-400 font-black block mb-2.5">۳. نوع بازدید در محل:</span>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => setBookingType('in_person')}
                        className={`py-3.5 rounded-2xl text-xs font-black border transition-all cursor-pointer ${
                          bookingType === 'in_person'
                            ? 'bg-blue-600 text-white border-blue-600'
                            : 'bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-200/40 dark:border-slate-800'
                        }`}
                      >
                        حضور در محل ملک
                      </button>
                      <button
                        type="button"
                        onClick={() => setBookingType('video_call')}
                        className={`py-3.5 rounded-2xl text-xs font-black border transition-all cursor-pointer ${
                          bookingType === 'video_call'
                            ? 'bg-blue-600 text-white border-blue-600'
                            : 'bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-200/40 dark:border-slate-800'
                        }`}
                      >
                        سند/مشاوره تصویری
                      </button>
                    </div>
                  </div>

                  {/* Submission and trigger feedback */}
                  <button
                    type="submit"
                    className="w-full py-4 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white text-sm font-black transition-all shadow-lg shadow-blue-500/10 active:scale-95 cursor-pointer mt-2"
                  >
                    ثبت نهایی درخواست بازدید
                  </button>
                </motion.form>
              ) : (
                <motion.div 
                  key="booking-success"
                  className="py-6 text-center space-y-4"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0 }}
                >
                  <div className="w-14 h-14 bg-emerald-100 dark:bg-emerald-900/20 rounded-full flex items-center justify-center text-emerald-600 dark:text-emerald-400 mx-auto space-x-reverse">
                    <CheckCircle className="w-7 h-7" />
                  </div>
                  <h4 className="font-extrabold text-slate-900 dark:text-white text-base">درخواست شما ثبت شد!</h4>
                  <div className="bg-emerald-50 dark:bg-emerald-950/40 p-3.5 rounded-2.5xl text-xs text-emerald-800 dark:text-emerald-300 text-right space-y-1.5 border border-emerald-100 dark:border-emerald-900/50 leading-loose">
                    <p>📅 <b>زمان رزروشده:</b> {DAYS[selectedDayIndex].name} ({DAYS[selectedDayIndex].date}) </p>
                    <p>⏰ <b>بازه فوق:</b> {TIME_SLOTS[selectedSlotIndex]}</p>
                    <p>🔘 <b>روش هماهنگی:</b> {bookingType === 'in_person' ? 'حضور فیزیکی در محل آدرس ملک' : 'مشاوره تصویری واتساپ'}</p>
                    <p className="border-t border-emerald-100 dark:border-emerald-900/60 pt-1.5 text-[10px] text-slate-400 mt-1 pb-1">سیستم به کارشناس مربوطه اطلاع ارسال کرد. با شما تماس گرفته خواهد شد.</p>
                  </div>
                  <button
                    onClick={() => setIsBookingSubmitted(false)}
                    className="text-xs text-blue-600 dark:text-blue-400 font-extrabold hover:underline"
                  >
                    ثبت درخواست جدید دیگر
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Quick Contact buttons sidebar box */}
          <div className="bg-slate-50 dark:bg-slate-900 rounded-[2.5rem] p-6 border border-slate-200/50 dark:border-slate-800 shadow-xs space-y-4">
            <h4 className="font-black text-sm text-slate-900 dark:text-white mb-2">ارتباط مستقیم با کارشناس آگهی</h4>
            <div className="flex gap-2">
              <button 
                onClick={onChatClick}
                className="bg-blue-600 hover:bg-blue-550 text-white w-12 h-12 rounded-xl flex items-center justify-center transition-all shadow-lg shadow-blue-500/10 active:scale-95 cursor-pointer shrink-0"
                title="شروع گفتگوی چت"
              >
                <MessageCircle className="w-5 h-5" />
              </button>
              <button className="flex-1 bg-slate-900 dark:bg-white text-white dark:text-slate-900 h-12 rounded-xl font-black text-xs flex items-center justify-center gap-2 hover:bg-slate-800 dark:hover:bg-slate-100 transition-all active:scale-95 shadow-sm cursor-pointer">
                <Phone className="w-4 h-4" />
                تماس تلفنی با مالک
              </button>
            </div>
            <div className="flex items-start gap-2 text-[10px] text-slate-400/90 leading-relaxed pt-2 border-t border-slate-200/30 dark:border-slate-800">
              <Info className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
              <span>هوم‌هاب بر کلیه قراردادهای هماهنگ شده نظارت قانونی داشته و از سوء استفاده‌های احتمالی جلوگیری می‌کند.</span>
            </div>
          </div>
        </div>
      </div>

      {/* FOOTER SPACE */}
      <div className="h-28 md:h-12" />

      {/* 3D Virtual Tour Embed Modal */}
      <AnimatePresence>
        {isTourOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.98 }}
            className="fixed inset-0 z-[110] bg-slate-950 flex flex-col"
            dir="rtl"
          >
            {/* Modal header */}
            <div className="bg-slate-900 border-b border-slate-800 px-6 py-4 flex items-center justify-between text-white">
              <div className="flex items-center gap-3">
                <View360 className="w-8 h-8 text-blue-400 animate-pulse" />
                <div>
                  <h4 className="font-black text-sm text-slate-105">{property.title}</h4>
                  <p className="text-xs text-slate-450">نمای داخلی تعاملی و ۳۶۰ درجه</p>
                </div>
              </div>
              <button
                onClick={() => setIsTourOpen(false)}
                className="w-10 h-10 bg-slate-800 hover:bg-slate-700 active:scale-90 rounded-full flex items-center justify-center text-slate-300 transition-all cursor-pointer"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Quick helper banner */}
            <div className="bg-blue-600/10 border-b border-blue-500/20 px-6 py-3.5 text-xs text-blue-300 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-center select-none font-bold">
              <span>📱 <b>بدون نیاز به عینک VR:</b> روی گوشی یا تبلت خود به راحتی بچرخید</span>
              <span>🔘 <b>حرکت در خانه:</b> دکمه‌ها و فلش‌های درون به شما اجازه رفتن به اتاق‌های دیگر را می‌دهند</span>
            </div>

            {/* Virtual Tour Embed Iframe */}
            <div className="flex-1 bg-slate-900 relative">
              <iframe
                src={property.virtualTourUrl || 'https://kuula.co/share/collection/79WNW?logo=1&info=1&fs=1&vr=0&sd=1&thumbs=1'}
                className="w-full h-full border-0 absolute inset-0"
                allowFullScreen
                referrerPolicy="no-referrer"
                title={`تور مجازی - ${property.title}`}
              />
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* FULL-SCREEN IMAGE LIGHTBOX GALLERY */}
      <AnimatePresence>
        {isGalleryOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[120] bg-black/95 flex flex-col justify-center items-center"
            dir="rtl"
          >
            {/* Gallery Header */}
            <div className="absolute top-0 inset-x-0 bg-slate-950/60 backdrop-blur-md px-6 py-4 text-white flex items-center justify-between z-10">
              <span className="font-extrabold text-sm md:text-base">گالری تصاویر ملک ({(currentImageIndex + 1).toLocaleString('fa-IR')} از {property.images.length.toLocaleString('fa-IR')})</span>
              <button 
                onClick={() => setIsGalleryOpen(false)} 
                className="w-10 h-10 bg-slate-900 hover:bg-slate-800 rounded-full flex items-center justify-center text-white"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Main Picture displaying with transitions */}
            <div className="relative max-w-4xl w-full px-4 aspect-video flex items-center justify-center">
              <img 
                src={property.images[currentImageIndex]} 
                className="max-h-[75vh] max-w-full rounded-3xl object-contain shadow-2xl border border-slate-800"
                alt="تصویر آگهی در ابعاد بزرگ" 
              />
            </div>

            {/* Gallery nav buttons */}
            {property.images.length > 1 && (
              <div className="flex gap-4 mt-6 z-10">
                <button 
                  onClick={prevImage}
                  className="w-12 h-12 bg-white/10 hover:bg-white/20 active:scale-95 text-white rounded-full flex items-center justify-center transition-all cursor-pointer"
                >
                  <ChevronRight className="w-6 h-6" />
                </button>
                <button 
                  onClick={nextImage}
                  className="w-12 h-12 bg-white/10 hover:bg-white/20 active:scale-95 text-white rounded-full flex items-center justify-center transition-all cursor-pointer"
                >
                  <ChevronLeft className="w-6 h-6" />
                </button>
              </div>
            )}

            {/* Image Preview thumbnails */}
            <div className="absolute bottom-6 flex gap-2 overflow-x-auto max-w-2xl px-4 scrollbar-hide py-1">
              {property.images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setCurrentImageIndex(idx)}
                  className={`w-16 h-12 rounded-lg overflow-hidden shrink-0 border-2 transition-all ${
                    idx === currentImageIndex ? 'border-blue-500 scale-105' : 'border-transparent opacity-60'
                  }`}
                >
                  <img src={img} className="w-full h-full object-cover" alt="" />
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

    </motion.div>
  );
}

function SpecDetailItem({ label, value }: { label: string; value: string }) {
  return (
    <div className="bg-slate-50 dark:bg-slate-800/40 p-4 rounded-2xl border border-slate-100 dark:border-slate-800 text-right">
      <span className="text-[10px] text-slate-400 dark:text-slate-500 font-bold block mb-1">{label}</span>
      <span className="text-xs md:text-sm font-black text-slate-800 dark:text-slate-200">{value}</span>
    </div>
  );
}
